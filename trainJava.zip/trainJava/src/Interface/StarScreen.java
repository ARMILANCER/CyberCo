package Interface;
import Home.StateMachine;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.io.File;
import java.io.IOException;
public class StarScreen extends JFrame {
    // attributes for the background image
    private ImageIcon imageBackground = new ImageIcon();
    JLabel backGroundImage = new JLabel(imageBackground);

    // attributes buttons
    JButton start = new JButton("START");
    public StarScreen(){
        // set Image
        setImage();
        setContentPane(backGroundImage);

        // set Button start
        start.setBounds(284,515 , 120, 40);
        start.addActionListener(e->{
            StateMachine.add("charge", new Charge());
            try {
                StateMachine.changeWindow("startScreen","charge");
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        });
        add(start);
        setSize(700,700);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }
    public void setImage() {
        new Thread(()->{
         try{
                imageBackground.setImage(ImageIO.read(new File("Image/menu.jpeg")));
            } catch(
            IOException e) {
                throw new RuntimeException(e);
            }
        }).start();
    }
}
