package Interface;
import OtherComponents.StationCanvas;
import javax.swing.*;
public class Station extends JFrame{
    ///////
    ///
    //////
    StationCanvas canvas = new StationCanvas();
    ///////
    ///
    ///////
    public Station(){
        add(canvas);
        try {
            Thread.sleep(20);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        // set Frame
        setExtendedState(MAXIMIZED_BOTH);
        setUndecorated(true);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

}