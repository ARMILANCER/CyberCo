package GetData;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
public class Station{
    Image stationImage;
    public Image getStationImage(){
        try {
            BufferedImage buffImage = ImageIO.read(new File("Image/Station.png"));
            stationImage = buffImage.getScaledInstance(1440,862,Image.SCALE_DEFAULT);
        }catch (IOException e){
            e.printStackTrace();
        }
        return stationImage;
    }
}