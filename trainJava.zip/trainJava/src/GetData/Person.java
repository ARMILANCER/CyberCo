package GetData;

import java.awt.*;
import java.util.Random;
public class Person{
    private Image image;
    public void randPerson(){
        Random randomPerson = new Random();
        int randNum = randomPerson.nextInt((6-1)+1)+1;
        Toolkit tk = Toolkit.getDefaultToolkit();
        image = tk.getImage("person"+randNum+".png");
    }

}
