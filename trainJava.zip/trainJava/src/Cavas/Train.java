package Cavas;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Train extends Canvas {
    private Image trainCloseIm,trainOpenIm;
    public Train(){
        setBackground(new Color(0,0,0,0));
        try {
            BufferedImage buffImageTrainC = ImageIO.read(new File("Image/trainC.png"));
            trainCloseIm = buffImageTrainC.getScaledInstance(1478 ,840,Image.SCALE_DEFAULT);
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    public Train(GraphicsConfiguration config) {
        super(config);
    }

    @Override
    public void addNotify() {
        super.addNotify();
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
    }

    @Override
    public void update(Graphics g) {
        super.update(g);
    }
}
