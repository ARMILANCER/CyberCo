package OtherComponents;
import GetData.Station;
import GetData.Train;
import javax.swing.*;
import java.awt.*;
import static java.lang.Thread.sleep;
public class StationCanvas extends JPanel implements Runnable {
    ///////
    /// allocate of Stazione
    ///////
    Station stazione = new Station();
    ///////
    /// allocate of GetData.Train
    ///////
    Train train = new Train();
    Thread animator;
    private volatile boolean running = false;
    private volatile boolean gameOver = false;
    int moveTrainY=-15;
    int FPS = 30;
    ///////
    /// State train
    ///////
    boolean move = true;
    public void addNotify(){
        super.addNotify();
        startGame();
    }
    public void startGame(){
        if(animator==null || !running){
            animator = new Thread(this);
            animator.start();
        }
    }
    public void stopGame(){
        running = false;
    }
    @Override
    public void run() {
        running = true;
        while (running) {
            gameUpdate();
            repaint();
            try {
                sleep(20);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
    private void gameUpdate(){
        double drawInternal = 1000000000/FPS*8;
        double nextDrawTime = System.nanoTime()+drawInternal;
        if(!gameOver) {
            try {
                double remainingTime = nextDrawTime - System.nanoTime();
                remainingTime = remainingTime / 1000000000;
                if (remainingTime <= 0) {
                    remainingTime = 0;
                }
                sleep((long) remainingTime);
                moveTrainY -= 15;
                if (moveTrainY == -1500) {
                    moveTrainY = 1500;
                } else if (moveTrainY == -15) {
                    sleep(6000);
                    move = true;
                    repaint();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    @Override
    public void paint(Graphics g) {
        g.drawImage(stazione.getStationImage(), 0, 0,this );
        if(!move) g.drawImage(train.getTrainOpenImage(), moveTrainY, 10, this);
        else if(move) g.drawImage(train.getTrainCloseImage(), moveTrainY, 10, this);
    }
}