package GetData;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
public class Train{
    private Image trainCloseIm,trainOpenIm;
    public Image getTrainOpenImage(){
        new Thread(()->{
            try {
                BufferedImage buffImageTrainO = ImageIO.read(new File("Image/trainO.png"));
                trainOpenIm = buffImageTrainO.getScaledInstance(1478, 840, Image.SCALE_DEFAULT);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        return trainOpenIm;
    }
    public Image getTrainCloseImage(){
        try {
            BufferedImage buffImageTrainC = ImageIO.read(new File("Image/trainC.png"));
            trainCloseIm = buffImageTrainC.getScaledInstance(1478 ,840,Image.SCALE_DEFAULT);
        }catch (IOException e){
            e.printStackTrace();
        }
        return trainCloseIm;
    }
}