package Home;

import javax.swing.*;
import java.util.HashMap;
public class StateMachine {
    private static HashMap<String, JFrame> states = new HashMap<>();
    private static JFrame lastShwon = null;
    public static void add(String name,JFrame reference) {
        states.put(name, reference);
    }
    public static void changeWindow(String previous,String next) throws Exception {
        if(!states.containsKey(next)) throw new Exception("States doesn't found");
        if(!states.containsKey(previous)) throw new Exception("States doesn't found");
        states.get(previous).setVisible(false);
        states.get(next).setVisible(true);
    }

    public static void deleteChange(String previous,String next)throws Exception{
        if(!states.containsKey(next)) throw new Exception("States doesn't found");
        if(!states.containsKey(previous)) throw new Exception("States doesn't found");
        states.get(previous).setVisible(false);
        states.remove(previous);
        states.get(next).setVisible(true);
    }
    public static void show(String what) throws Exception {
        if(!states.containsKey(what)) throw new Exception("States doesn't found");
        lastShwon = states.get(what);
        lastShwon.setVisible(true);
    }
    public static void close(String what) throws Exception {
        if(!states.containsKey(what)) throw new Exception("States doesn't found");
        lastShwon = states.get(what);
        lastShwon.dispose();
    }
}