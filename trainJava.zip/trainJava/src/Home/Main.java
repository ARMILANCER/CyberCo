package Home;

import Interface.StarScreen;

public class Main extends StateMachine{
    public static void main(String [] args){
        add("startScreen", new StarScreen());
        try {
            show("startScreen");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
