package Interface;
import Home.StateMachine;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
public class Charge extends JFrame {
    private ImageIcon imageBackground = new ImageIcon();
    JLabel backGroundImage = new JLabel(imageBackground);

    // progress bar
    JProgressBar progressBar = new JProgressBar(0,100);
    JPanel panel = new JPanel();
    Timer timer;

    Charge(){
        setLayout(new FlowLayout());
        // set Image
        setImage();
        setContentPane(backGroundImage);

        // progress bar
        charge();
        progressBar.setVisible(true);
        progressBar.setStringPainted(true);
        progressBar.setBounds(100, 450, 400, 100);

        add(progressBar);

        setSize(600,600);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }
    public void setImage(){

        try {
            imageBackground.setImage(ImageIO.read(new File("Image/chargeImage.jpeg")));
        } catch(
        IOException e){
            e.printStackTrace();
        }
    }
    public void charge(){
        timer = new Timer(100, e->{
            int i= progressBar.getValue();
            try {
                if(i < 100){
                    i++;
                    progressBar.setValue(i+15);
                    Thread.sleep(800);
                }else {
                    timer.stop();
                    StateMachine.add("station", new Station());
                    StateMachine.deleteChange("charge","station");
                }
            }catch (Exception ex){
                ex.printStackTrace();
            }
        });
        timer.start();
    }
}